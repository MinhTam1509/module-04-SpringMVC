package com.codegym.injection.constructor;

public class SpellChecker {

    public void checkSpelling() {
        System.out.println("Check Spelling...");
    }
}
