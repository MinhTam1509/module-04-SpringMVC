package com.codegym.none_di.service;

public class EmailService {

    public void sendMessage() {
        System.out.println("Email sending...");
    }
}
