package com.codegym.injection.field;

public interface OrderService {

    String orderFood();
}
