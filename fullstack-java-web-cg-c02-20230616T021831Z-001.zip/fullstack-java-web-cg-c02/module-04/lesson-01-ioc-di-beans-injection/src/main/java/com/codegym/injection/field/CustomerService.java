package com.codegym.injection.field;

public interface CustomerService {

    String eat();
    String drink();
}
