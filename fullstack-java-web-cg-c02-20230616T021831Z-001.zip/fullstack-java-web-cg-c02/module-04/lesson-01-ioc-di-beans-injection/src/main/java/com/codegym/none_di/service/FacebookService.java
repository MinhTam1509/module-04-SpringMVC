package com.codegym.none_di.service;

public class FacebookService {

    public void sendMessage() {
        System.out.println("Facebook sending...");
    }
}
