package com.codegym.none_di.service;

public class SmsService {

    public void sendMessage() {
        System.out.println("Sms sending...");
    }
}
