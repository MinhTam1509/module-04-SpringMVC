package com.codegym.use_di.service;

public interface DIMessageService {

    void sendMessage();

}
